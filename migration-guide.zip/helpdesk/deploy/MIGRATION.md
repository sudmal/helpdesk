# Перенос HelpDesk на новый VPS

## Шаг 1: Сохраняем текущий проект в Git (на старом сервере)

```bash
cd /var/www/sites/helpdesk

# Инициализируем git если ещё нет
git init
git add .
git commit -m "production ready"

# Пушим на GitHub/GitLab
git remote add origin https://github.com/ВАШ_АККАУНТ/helpdesk.git
git push -u origin main
```

## Шаг 2: Дамп базы данных (на старом сервере)

```bash
# Делаем дамп БД
mysqldump -u root -p helpdesk > /tmp/helpdesk_db.sql

# Копируем на новый сервер
scp /tmp/helpdesk_db.sql root@НОВЫЙ_IP:/tmp/

# Копируем загруженные файлы (вложения к заявкам)
scp -r /var/www/sites/helpdesk/storage/app/public root@НОВЫЙ_IP:/tmp/helpdesk_storage/
```

## Шаг 3: Подготовка нового VPS (Ubuntu 22.04/24.04)

```bash
# Обновляем систему
apt update && apt upgrade -y

# Устанавливаем всё необходимое одной командой
apt install -y \
    nginx \
    mysql-server \
    php8.2 \
    php8.2-fpm \
    php8.2-mysql \
    php8.2-mbstring \
    php8.2-xml \
    php8.2-curl \
    php8.2-zip \
    php8.2-intl \
    php8.2-bcmath \
    php8.2-redis \
    php8.2-gd \
    redis-server \
    supervisor \
    certbot \
    python3-certbot-nginx \
    git \
    curl \
    unzip

# Устанавливаем Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Устанавливаем Composer
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer
chmod +x /usr/local/bin/composer
```

## Шаг 4: Настройка MySQL

```bash
# Защищаем MySQL
mysql_secure_installation

# Создаём БД и пользователя
mysql -u root -p << 'SQL'
CREATE DATABASE helpdesk CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'helpdesk'@'localhost' IDENTIFIED BY 'ПРИДУМАЙТЕ_ПАРОЛЬ';
GRANT ALL PRIVILEGES ON helpdesk.* TO 'helpdesk'@'localhost';
FLUSH PRIVILEGES;
SQL

# Восстанавливаем дамп
mysql -u root -p helpdesk < /tmp/helpdesk_db.sql
```

## Шаг 5: Разворачиваем проект

```bash
# Создаём директорию
mkdir -p /var/www/sites
cd /var/www/sites

# Клонируем проект
git clone https://github.com/ВАШ_АККАУНТ/helpdesk.git helpdesk
cd helpdesk

# Устанавливаем зависимости PHP
COMPOSER_ALLOW_SUPERUSER=1 composer install --optimize-autoloader

# Устанавливаем зависимости Node и собираем
npm ci
npm install @inertiajs/vue3@^2.0   # ВАЖНО: именно v2!
npm run build

# Копируем .env
cp .env.example .env
php artisan key:generate
```

## Шаг 6: Настройка .env

```bash
nano .env
```

Заполните:
```env
APP_NAME="HelpDesk"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://ВАШ_ДОМЕН

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=helpdesk
DB_USERNAME=helpdesk
DB_PASSWORD=ПРИДУМАЙТЕ_ПАРОЛЬ

CACHE_DRIVER=file
SESSION_DRIVER=file
QUEUE_CONNECTION=sync

MAIL_MAILER=smtp
MAIL_HOST=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=helpdesk@example.com
MAIL_PASSWORD=
MAIL_FROM_ADDRESS=helpdesk@example.com

TELEGRAM_BOT_TOKEN=

LANBILLING_URL=
LANBILLING_LOGIN=
LANBILLING_PASSWORD=
```

## Шаг 7: Финальная настройка Laravel

```bash
cd /var/www/sites/helpdesk

# Права на директории
chown -R www-data:www-data /var/www/sites/helpdesk
chmod -R 755 /var/www/sites/helpdesk
chmod -R 775 storage bootstrap/cache

# Storage link
php artisan storage:link

# Восстанавливаем загруженные файлы
cp -r /tmp/helpdesk_storage/* storage/app/public/

# Миграции (БД уже восстановлена из дампа — пропустить если дамп был)
# php artisan migrate --seed

# Кэш
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## Шаг 8: nginx

```bash
# Временный HTTP конфиг для получения сертификата
cat > /etc/nginx/sites-available/helpdesk << 'NGINX'
server {
    listen 80;
    server_name ВАШ_ДОМЕН;
    root /var/www/sites/helpdesk/public;
    index index.php;
    client_max_body_size 110M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
    }

    location ~* \.(css|js|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|webp)$ {
        expires 1y;
        access_log off;
    }

    location ~ /\. { deny all; }
}
NGINX

ln -sf /etc/nginx/sites-available/helpdesk /etc/nginx/sites-enabled/helpdesk
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
```

## Шаг 9: SSL

```bash
certbot --nginx -d ВАШ_ДОМЕН
# Выбрать "2" — Redirect (перенаправлять HTTP на HTTPS)

# Проверить автообновление
certbot renew --dry-run
```

## Шаг 10: Supervisor (очереди и планировщик)

```bash
cat > /etc/supervisor/conf.d/helpdesk.conf << 'SUP'
[program:helpdesk-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/sites/helpdesk/artisan queue:work --sleep=3 --tries=3 --max-time=3600
directory=/var/www/sites/helpdesk
autostart=true
autorestart=true
user=www-data
numprocs=2
redirect_stderr=true
stdout_logfile=/var/log/supervisor/helpdesk-worker.log

[program:helpdesk-scheduler]
process_name=%(program_name)s
command=php /var/www/sites/helpdesk/artisan schedule:work
directory=/var/www/sites/helpdesk
autostart=true
autorestart=true
user=www-data
redirect_stderr=true
stdout_logfile=/var/log/supervisor/helpdesk-scheduler.log
SUP

mkdir -p /var/log/supervisor
supervisorctl reread
supervisorctl update
supervisorctl start helpdesk-worker:*
supervisorctl start helpdesk-scheduler
supervisorctl status
```

## Шаг 11: Проверка

```bash
# Всё работает?
systemctl status nginx php8.2-fpm mysql redis supervisor

# Логи Laravel
tail -20 /var/www/sites/helpdesk/storage/logs/laravel.log

# Очереди работают?
supervisorctl status

# Тест планировщика
php artisan schedule:list
```

## Важные заметки

**ОБЯЗАТЕЛЬНО** перед переносом на новый VPS:
1. Измените пароль администратора в системе
2. Смените `APP_KEY` — `php artisan key:generate`
3. Установите надёжный пароль для MySQL
4. Проверьте что `APP_DEBUG=false`

**Логин по умолчанию:**
- Email: `admin@helpdesk.local`
- Пароль: `Admin1234!`
- **Смените пароль сразу после первого входа!**
